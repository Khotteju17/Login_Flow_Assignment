//
//  VerificationViewController.swift
//  Weboconnect_Assignment
//
//  Created by Tejashree on 30/05/24.
//

import Foundation
import UIKit

class VerificationViewController: UIViewController, UITextFieldDelegate {
  
    @IBOutlet weak var txtFieldOTP1: UITextField!
    @IBOutlet weak var txtFieldOTP2: UITextField!
    @IBOutlet weak var txtFieldOTP3: UITextField!
    @IBOutlet weak var txtFieldOTP4: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtFieldOTP1.textAlignment = .center
        txtFieldOTP2.textAlignment = .center
        txtFieldOTP3.textAlignment = .center
        txtFieldOTP4.textAlignment = .center
        
        txtFieldOTP1.delegate = self
        txtFieldOTP2.delegate = self
        txtFieldOTP3.delegate = self
        txtFieldOTP4.delegate = self
        
        txtFieldOTP1.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtFieldOTP2.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtFieldOTP3.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtFieldOTP4.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    // MARK: - TextFieldDelegate Methods
    
    @objc func textFieldDidChange(_ textField: UITextField) {
           let text = textField.text
           
           if text?.count == 1 {
               switch textField {
               case txtFieldOTP1:
                   txtFieldOTP2.becomeFirstResponder()
               case txtFieldOTP2:
                   txtFieldOTP3.becomeFirstResponder()
               case txtFieldOTP3:
                   txtFieldOTP4.becomeFirstResponder()
               case txtFieldOTP4:
                   txtFieldOTP4.resignFirstResponder()
               default:
                   break
               }
           } else if text?.count == 0 {
               switch textField {
               case txtFieldOTP4:
                   txtFieldOTP3.becomeFirstResponder()
               case txtFieldOTP3:
                   txtFieldOTP2.becomeFirstResponder()
               case txtFieldOTP2:
                   txtFieldOTP1.becomeFirstResponder()
               case txtFieldOTP1:
                   txtFieldOTP1.resignFirstResponder()
               default:
                   break
               }
           }
       }
    
    // MARK: - IBActions
    
    @IBAction func backButtonClicked(_ sender: Any){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
    }
    
    @IBAction func submitButtonClicked(_ sender: Any) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(withIdentifier: "CreateProfileViewController") as! CreateProfileViewController
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
    }
   
    
    // MARK: - Func to enter only single character
    
       func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
           guard let text = textField.text else { return false }
           let newLength = text.count + string.count - range.length
           return newLength <= 1
       }
       
   }

