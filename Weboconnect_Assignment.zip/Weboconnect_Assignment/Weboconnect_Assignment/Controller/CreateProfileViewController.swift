//
//  CreateProfileViewController.swift
//  Weboconnect_Assignment
//
//  Created by Tejashree on 30/05/24.
//

import Foundation
import UIKit

class CreateProfileViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtFieldname: UITextField!
    @IBOutlet weak var txtFieldLastName: UITextField!
    @IBOutlet weak var txtFieldPhone: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTextField(txtFieldname)
        setupTextField(txtFieldLastName)
        setupTextField(txtFieldPhone)
    }
    
    // MARK: - TextFieldDelegate Methods
    
    func setupTextField(_ textField: UITextField) {
        textField.delegate = self
        textField.layer.borderWidth = 1.0
        textField.layer.borderColor = UIColor(red: 1.0, green: 0.498, blue: 0.365, alpha: 0.05).cgColor
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.layer.borderColor = UIColor(red: 1.0, green: 0.498, blue: 0.365, alpha: 1.0).cgColor
            }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.layer.borderColor = UIColor(red: 1.0, green: 0.498, blue: 0.365, alpha: 0.05).cgColor
            }
    
    // MARK: -  IBAction
    
    @IBAction func backButtonClicked(_ sender: Any){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(withIdentifier: "VerificationViewController") as! VerificationViewController
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
    }
}
