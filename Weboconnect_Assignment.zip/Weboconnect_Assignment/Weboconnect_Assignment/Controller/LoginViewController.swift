//
//  LoginViewController.swift
//  Weboconnect_Assignment
//
//  Created by Tejashree on 29/05/24.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtCountryCode: UITextField!
    @IBOutlet weak var txtPhoneNo: UITextField!
    @IBOutlet weak var txtOTP1: UITextField!
    @IBOutlet weak var txtOTP2: UITextField!
    @IBOutlet weak var txtOTP3: UITextField!
    @IBOutlet weak var txtOTP4: UITextField!
    @IBOutlet weak var popUpView:UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        popUpView.isHidden = true
        
        txtPhoneNo.delegate = self
      
        txtOTP1.textAlignment = .center
        txtOTP2.textAlignment = .center
        txtOTP3.textAlignment = .center
        txtOTP4.textAlignment = .center
        txtPhoneNo.textAlignment = .center
    }
    
    // MARK: - Func for Screen transition
    @objc func transitionToNextScreen() {
            let story = UIStoryboard(name: "Main", bundle: nil)
            let controller = story.instantiateViewController(withIdentifier: "VerificationViewController") as! VerificationViewController
            controller.modalPresentationStyle = .fullScreen
            self.present(controller, animated: true, completion: nil)
        }
        
    // MARK: - IBActions
    @IBAction func requestOTPButtonClicked(_ sender: Any) {
        popUpView.isHidden = false
        
        guard let phoneNumber = txtPhoneNo.text, !phoneNumber.isEmpty else {
            txtOTP1.text = "Invalid"
            txtOTP2.text = "number"
            txtOTP3.text = ""
            txtOTP4.text = ""
            print("Invalid number: txtPhoneNo is empty or nil")
            return
        }
        
        let formattedPhoneNumber = formatPhoneNumber(phoneNumber)
            print("Formatted phone number: \(formattedPhoneNumber)")  // Debugging print statement
            txtPhoneNo.text = formattedPhoneNumber
        
        let otp = generateOTP(from: phoneNumber)
        setOTPinTextFields(otp)
        print("Generated OTP: \(otp)")
    }
    
    @IBAction func backButtonClicked(_ sender: Any){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(withIdentifier: "SplashViewController") as! SplashViewController
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
    }
    
    // MARK: - Functions to generate OTP

    func formatPhoneNumber(_ phoneNumber: String) -> String {
        var formattedNumber = phoneNumber
        if formattedNumber.count == 10 {
            formattedNumber.insert(" ", at: formattedNumber.index(formattedNumber.startIndex, offsetBy: 5))
        }
        return formattedNumber
    }
    
    func generateOTP(from phoneNumber: String) -> String {
        let cleanedNumber = phoneNumber.replacingOccurrences(of: " ", with: "")
        guard cleanedNumber.count >= 10 else {
            print("Invalid number length: \(cleanedNumber.count)")
            return "Err"
        }
        var otp = ""
        otp.append(contentsOf: phoneNumber.prefix(1))
        otp.append(contentsOf: phoneNumber.prefix(2).suffix(1))
        otp.append(contentsOf: phoneNumber.suffix(2).prefix(1))
        otp.append(contentsOf: phoneNumber.suffix(1))
        
        print("OTP parts from phone number \(phoneNumber): \(phoneNumber.prefix(1)) \(phoneNumber.prefix(2).suffix(1)) \(phoneNumber.suffix(2).prefix(1)) \(phoneNumber.suffix(1))")
        return otp
    }
    
    func setOTPinTextFields(_ otp: String) {
        let otpArray = Array(otp)
        
        if otpArray.count >= 4 {
            txtOTP1.text = String(otpArray[0])
            txtOTP2.text = String(otpArray[1])
            txtOTP3.text = String(otpArray[2])
            txtOTP4.text = String(otpArray[3])
            Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(transitionToNextScreen), userInfo: nil, repeats: false)
              
        } else {
            // Handle the case where OTP is not 4 characters long, if necessary
            txtOTP1.text = "Err"
            txtOTP2.text = "or"
            txtOTP3.text = ""
            txtOTP4.text = ""
        }
    }
    
    // MARK: - UITextFieldDelegate Methods
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Limit the phone number to 10 digits
        if textField == txtPhoneNo {
            // Check if the replacement string is a valid digit
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            if !allowedCharacters.isSuperset(of: characterSet) {
                return false
            }
            
            // Limit the length to 10 digits
            let currentText = textField.text ?? ""
            let newLength = currentText.count + string.count - range.length
            return newLength <= 10
        }
        return true
    }
}

